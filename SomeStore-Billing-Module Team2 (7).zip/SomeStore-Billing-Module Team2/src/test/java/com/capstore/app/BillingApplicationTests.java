package test.java.com.capstore.app;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

import main.java.com.capstore.app.BillingApplication;


@SpringBootTest(classes=BillingApplication.class)
public class BillingApplicationTests {

	@Test
	void contextLoads() {
	}
}
