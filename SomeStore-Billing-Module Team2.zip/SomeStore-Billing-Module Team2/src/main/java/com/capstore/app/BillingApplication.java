package main.java.com.capstore.app;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"main.java.com.capstore.app.controller","main.java.com.capstore.app.models","main.java.com.capstore.app.repository","main.java.com.capstore.app.signup_login","main.java.com.capstore.app.exceptions"})
public class BillingApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(BillingApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
