package com.capstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
